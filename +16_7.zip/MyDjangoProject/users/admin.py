from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import CustomUser


@admin.register(CustomUser)
class CustomUserAdmin(UserAdmin):
    """
    Админ-класс для пользовательской модели CustomUser.

    Расширяет стандартный UserAdmin, добавляя отображение аватара в списке
    пользователей и возможность редактирования аватара в форме редактирования пользователя.

    Атрибуты:
        list_display (tuple): Определяет, какие поля отображаются в списке пользователей.
        fieldsets (tuple): Расширяет стандартные настройки, добавляя поле "avatar".
    """
    list_display = ('username', 'email', 'is_staff', 'is_active', 'avatar')  # Добавляем поле "avatar"
    fieldsets = UserAdmin.fieldsets + (  # Расширяем настройки
        ('Дополнительные поля', {'fields': ('avatar',)}),
    )
