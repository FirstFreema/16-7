from django.urls import reverse_lazy
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from django.contrib import messages
from .models import Dog
from .forms import DogForm

class DogListView(ListView):
    """
    Список всех собак.
    """
    model = Dog
    template_name = 'dogs/dog_list.html'
    context_object_name = 'dogs'

class DogDetailView(DetailView):
    """
    Просмотр информации о собаке.
    """
    model = Dog
    template_name = 'dogs/dog_detail.html'
    context_object_name = 'dog'

class DogCreateView(CreateView):
    """
    Создание новой собаки.
    """
    model = Dog
    form_class = DogForm
    template_name = 'dogs/dog_form.html'
    success_url = reverse_lazy('dogs:list_dogs')

    def form_valid(self, form):
        """
        Привязываем владельца текущему пользователю.
        """
        form.instance.owner = self.request.user
        messages.success(self.request, 'Собака успешно добавлена.')
        return super().form_valid(form)

    def form_invalid(self, form):
        """
        Обрабатываем ошибки формы.
        """
        messages.error(self.request, 'Исправьте ошибки в форме.')
        return super().form_invalid(form)

class DogUpdateView(UpdateView):
    """
    Редактирование собаки.
    """
    model = Dog
    form_class = DogForm
    template_name = 'dogs/dog_form.html'
    success_url = reverse_lazy('dogs:list_dogs')

    def form_invalid(self, form):
        """
        Обрабатываем ошибки формы.
        """
        messages.error(self.request, 'Исправьте ошибки в форме.')
        return super().form_invalid(form)

class DogDeleteView(DeleteView):
    """
    Удаление собаки.
    """
    model = Dog
    template_name = 'dogs/dog_confirm_delete.html'
    success_url = reverse_lazy('dogs:list_dogs')

    def post(self, request, *args, **kwargs):
        """
        Добавляем сообщение об успешном удалении.
        """
        messages.success(self.request, 'Собака успешно удалена.')
        return super().post(request, *args, **kwargs)
